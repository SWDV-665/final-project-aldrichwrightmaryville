import { Injectable } from '@angular/core';
import { AlertController} from '@ionic/angular';
import { TimesheetServiceService } from '../timesheet-service-service/timesheet-service.service';



/*type Grocery = {
  Item: string;
  Quantity: string;
  Price: string;
  Total: string
}; 

let item: { Item: string;  Quantity: string;  Price: string;  Total: string }[]  */

@Injectable({
  providedIn: 'root'
})  
export class InputDialogServiceService {

  

  constructor(public alertCtrl: AlertController, public dataService: TimesheetServiceService) { }

  /*async showItemPrompt(grocery?: Grocery, index?: number) {
    const prompt = await this.alertCtrl.create({
      
      message: grocery ? "Please edit item..." : "Please add Item",
      inputs: [
        {
          name: 'Item',
          placeholder: 'Name', value: grocery? grocery.Item: null
        },
        {
          name: 'Quantity',
          type: 'number',
          placeholder: 'Quantity', value: grocery? grocery.Quantity: null,
          min: 1,
          max: 10  
        },
        {
          name: 'Price',
          placeholder: 'Price', value: grocery? grocery.Price: null
        },

      ],
      buttons: [
        {
          text: 'Cancel',
          handler: data => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Save',
          handler: item => {
            console.log(item)
            if (index !== undefined)
             this.dataService.editItem(item,index)
            else 
            {
              console.log(item)
              this.dataService.addItem(item)
            } 
            }
        }
      ]
    });
    await prompt.present();
  }*/
}
