import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent implements OnInit {appPages = [
  {
    title: 'home',
    url: '/Home',
    icon: 'home'
  },
  {
    title: 'detail',
    url: '/Approved',
    icon: 'people'
  },
  {
    title: 'Rejected',
    url: '/Rejected',
    icon: 'map'
  },
  {
    title: 'About',
    url: '/app/tabs/about',
    icon: 'information-circle'
  }
];
  constructor() {}
  ngOnInit(): void {
    /*throw new Error('Method not implemented.');*/
  }
}
