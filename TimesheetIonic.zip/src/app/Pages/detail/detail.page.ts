import { Component, OnInit } from '@angular/core';
import { TimesheetServiceService } from '../../Providers/timesheet-service-service/timesheet-service.service';
import { InputDialogServiceService } from '../../Providers/input-dialog-service/input-dialog-service.service';

interface TimesheetDetail {
  timesheetId: number;
  Status: string;
  FirstName: string;
  LastName: string
};

@Component({
  selector: 'app-detail',
  templateUrl: './detail.page.html',
  styleUrls: ['./detail.page.scss'],
})
export class DetailPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
