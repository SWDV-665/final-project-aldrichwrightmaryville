import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ApprovedPageModule } from '../approved/approved.module';
import { RejectedPageModule } from '../rejected/rejected.module';

import { HomePage } from './home.page';

const routes: Routes = [
  {
    path: '',
    component: HomePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],  
  exports: [RouterModule],
})
export class HomePageRoutingModule {}
