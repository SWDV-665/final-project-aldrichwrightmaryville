import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { ApproveComponent } from './components/approve/approve.component';
import { DetailComponent } from './components/detail/detail.component';
import { DetailPageModule } from './Pages/detail/detail.module';
import { RejectComponent } from './components/reject/reject.component';


const routes: Routes = [
  { path: 'detail', component: DetailComponent},
  { path: 'Approved', component: ApproveComponent},
  { path: 'Rejected', component: RejectComponent},
  {
    path: '',
    loadChildren: () => import('./Pages/tabs/tabs.module').then(m => m.TabsPageModule)
  },
  {
    path: 'home',
    loadChildren: () => import('./Pages/home/home.module').then( m => m.HomePageModule)
  },
  {
    path: 'about',
    loadChildren: () => import('./Pages/about/about.module').then( m => m.AboutPageModule)
  },
  {
    path: 'contact',
    loadChildren: () => import('./Pages/contact/contact.module').then( m => m.ContactPageModule)
  },
  {
    path: 'detail',
    loadChildren: () => import('./Pages/detail/detail.module').then( m => m.DetailPageModule)
  },
  {
    path: 'approved',
    loadChildren: () => import('./Pages/approved/approved.module').then( m => m.ApprovedPageModule)
  },
  {
    path: 'rejected',
    loadChildren: () => import('./Pages/rejected/rejected.module').then( m => m.RejectedPageModule)
  }
];
@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
