import { Component, OnInit } from '@angular/core';
import { AlertController } from '@ionic/angular';
import { ToastController } from '@ionic/angular';
import { NavController } from '@ionic/angular';
import { Router } from '@angular/router';
import { InputDialogServiceService } from 'src/app/Providers/input-dialog-service/input-dialog-service.service';
import { TimesheetServiceService } from 'src/app/Providers/timesheet-service-service/timesheet-service.service';


@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.scss'],
})
export class DetailComponent implements OnInit {

  constructor(public navCtrl: NavController, public toastCtrl: ToastController, public alertCtrl: AlertController, public dataService: TimesheetServiceService, public inputService: InputDialogServiceService, public router: Router ) { }

  ngOnInit() {}

  loadDetailItem()
  {
    return this.dataService.getDetailItems();
  }

}
